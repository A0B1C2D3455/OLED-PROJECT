//include all header files
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "sra_board.h"

void app_main()
{
    ESP_ERROR_CHECK(enable_bar_graph());
    // enable_bar_graph() turns on the gpio pins, if it succeeds it returns ESP_OK else it returns ESP_FAIL
    // If the argument of ESP_ERROR_CHECK() is not equal ESP_OK, then an error message is printed on the console, and abort() is called. 
    
    while(1)
    {
        //var1 represents the pattern where all even positioned LEDs are off 
        uint8_t var1 = 0b10101010;

        //var2 represents the pattern where all odd positioned LEDs are off
        uint8_t var2 = 0b01010101;

        //inter is a placeholder variable which holds the value
        //of a pattern in each iteration of the while loop
        uint8_t inter = var1;

        while(1)
        {   
            //in each iteration, the value of inter is checked;
            //if the value is equal to the pattern stored in var1,
            //the pattern stored in var2 is assigned to inter
            //and vice-versa 
            
            if (inter == var1) {
                inter = var2;
            } else {
                inter = var1;
            }            

            //displays the current pattern held by inter
            ESP_ERROR_CHECK(set_bar_graph(inter));

            //delay of 1s
            vTaskDelay(1000 / portTICK_PERIOD_MS);
        }
    }
}
